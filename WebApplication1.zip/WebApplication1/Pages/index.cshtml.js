// JavaScript for index view
